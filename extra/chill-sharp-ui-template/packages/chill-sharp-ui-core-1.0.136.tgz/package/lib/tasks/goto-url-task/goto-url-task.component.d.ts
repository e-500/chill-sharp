import { OnDestroy } from '@angular/core';
import type { WorkspaceTaskComponentInterface, WorkspaceTaskConfiguration } from '../../models/workspace-task.models';
import * as i0 from "@angular/core";
interface GoToUrlTaskConfiguration {
    url: string;
    target: string;
}
type GoToUrlOpenState = 'pending' | 'opened' | 'blocked' | 'invalid';
export declare class GoToUrlTaskComponent implements WorkspaceTaskComponentInterface, OnDestroy {
    static getComponentConfigurationJsonExample(): WorkspaceTaskConfiguration | null;
    private readonly document;
    private readonly toolbar;
    readonly componentConfiguration: import("@angular/core").InputSignal<WorkspaceTaskConfiguration | null>;
    readonly toolbarScope: import("@angular/core").InputSignal<string>;
    readonly visible: import("@angular/core").InputSignal<boolean>;
    readonly openState: import("@angular/core").WritableSignal<GoToUrlOpenState>;
    readonly configuration: import("@angular/core").Signal<GoToUrlTaskConfiguration | null>;
    readonly heading: import("@angular/core").Signal<"Link opened" | "Popup blocked" | "Invalid configuration" | "Opening link">;
    readonly message: import("@angular/core").Signal<string>;
    private hasAttemptedOpen;
    constructor();
    ngOnDestroy(): void;
    handleWindowKeydown(event: KeyboardEvent): void;
    openConfiguredUrl(): void;
    private readConfiguration;
    private readConfigurationString;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoToUrlTaskComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GoToUrlTaskComponent, "app-goto-url-task", never, { "componentConfiguration": { "alias": "componentConfiguration"; "required": false; "isSignal": true; }; "toolbarScope": { "alias": "toolbarScope"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
export {};
//# sourceMappingURL=goto-url-task.component.d.ts.map