import * as i0 from "@angular/core";
export declare class ChillPolymorphicOutputValueControlComponent {
    readonly text: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicOutputValueControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicOutputValueControlComponent, "app-chill-polymorphic-output-value-control", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-output-value-control.component.d.ts.map