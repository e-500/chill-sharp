import * as i0 from "@angular/core";
export declare class ChillPolymorphicOutputBooleanControlComponent {
    readonly text: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicOutputBooleanControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicOutputBooleanControlComponent, "app-chill-polymorphic-output-boolean-control", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-output-boolean-control.component.d.ts.map