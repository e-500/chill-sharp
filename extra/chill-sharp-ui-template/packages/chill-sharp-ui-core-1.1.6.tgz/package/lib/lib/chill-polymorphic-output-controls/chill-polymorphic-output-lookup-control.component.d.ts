import * as i0 from "@angular/core";
export declare class ChillPolymorphicOutputLookupControlComponent {
    readonly text: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicOutputLookupControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicOutputLookupControlComponent, "app-chill-polymorphic-output-lookup-control", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-output-lookup-control.component.d.ts.map