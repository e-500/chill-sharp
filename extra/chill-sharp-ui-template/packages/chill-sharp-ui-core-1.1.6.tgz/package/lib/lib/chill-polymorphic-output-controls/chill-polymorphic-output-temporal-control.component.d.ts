import * as i0 from "@angular/core";
export declare class ChillPolymorphicOutputTemporalControlComponent {
    readonly parts: import("@angular/core").InputSignal<string[] | null>;
    readonly text: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicOutputTemporalControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicOutputTemporalControlComponent, "app-chill-polymorphic-output-temporal-control", never, { "parts": { "alias": "parts"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-output-temporal-control.component.d.ts.map