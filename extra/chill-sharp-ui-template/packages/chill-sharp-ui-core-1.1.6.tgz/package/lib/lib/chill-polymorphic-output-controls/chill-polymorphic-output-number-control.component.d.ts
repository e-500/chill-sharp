import * as i0 from "@angular/core";
export declare class ChillPolymorphicOutputNumberControlComponent {
    readonly text: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicOutputNumberControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicOutputNumberControlComponent, "app-chill-polymorphic-output-number-control", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-output-number-control.component.d.ts.map