import { FormControl } from '@angular/forms';
import type { JsonValue } from '@chill-sharp/ng-client';
import * as i0 from "@angular/core";
export declare class ChillPolymorphicBooleanControlComponent {
    readonly control: import("@angular/core").InputSignal<FormControl<JsonValue>>;
    readonly name: import("@angular/core").InputSignal<string>;
    readonly readOnly: import("@angular/core").InputSignal<boolean>;
    readonly blur: import("@angular/core").OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicBooleanControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicBooleanControlComponent, "app-chill-polymorphic-boolean-control", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "name": { "alias": "name"; "required": true; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; }, { "blur": "blur"; }, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-boolean-control.component.d.ts.map