import { FormControl } from '@angular/forms';
import type { JsonValue } from '@chill-sharp/ng-client';
import * as i0 from "@angular/core";
export declare class ChillPolymorphicScalarControlComponent {
    readonly control: import("@angular/core").InputSignal<FormControl<JsonValue>>;
    readonly name: import("@angular/core").InputSignal<string>;
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly readOnly: import("@angular/core").InputSignal<boolean>;
    readonly formatted: import("@angular/core").InputSignal<boolean>;
    readonly value: import("@angular/core").InputSignal<string>;
    readonly type: import("@angular/core").InputSignal<"number" | "text">;
    readonly step: import("@angular/core").InputSignal<string | null>;
    readonly staticSuffix: import("@angular/core").InputSignal<string>;
    readonly valueChange: import("@angular/core").OutputEmitterRef<string>;
    readonly blur: import("@angular/core").OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicScalarControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicScalarControlComponent, "app-chill-polymorphic-scalar-control", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "name": { "alias": "name"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; "formatted": { "alias": "formatted"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "staticSuffix": { "alias": "staticSuffix"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "blur": "blur"; }, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-scalar-control.component.d.ts.map