import { FormControl } from '@angular/forms';
import type { JsonValue } from '@chill-sharp/ng-client';
import * as i0 from "@angular/core";
export declare class ChillPolymorphicTextareaControlComponent {
    readonly control: import("@angular/core").InputSignal<FormControl<JsonValue>>;
    readonly name: import("@angular/core").InputSignal<string>;
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly readOnly: import("@angular/core").InputSignal<boolean>;
    readonly blur: import("@angular/core").OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicTextareaControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicTextareaControlComponent, "app-chill-polymorphic-textarea-control", never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "name": { "alias": "name"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; }, { "blur": "blur"; }, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-textarea-control.component.d.ts.map