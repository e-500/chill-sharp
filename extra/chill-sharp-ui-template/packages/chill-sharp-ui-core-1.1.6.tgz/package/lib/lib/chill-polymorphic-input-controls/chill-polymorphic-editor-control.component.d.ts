import { ChillService } from '../../services/chill.service';
import * as i0 from "@angular/core";
export declare class ChillPolymorphicEditorControlComponent {
    readonly chill: ChillService;
    readonly value: import("@angular/core").InputSignal<string>;
    readonly language: import("@angular/core").InputSignal<"json" | "plaintext">;
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly invalid: import("@angular/core").InputSignal<boolean>;
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    readonly valueChange: import("@angular/core").OutputEmitterRef<string>;
    readonly blur: import("@angular/core").OutputEmitterRef<void>;
    readonly beginDialog: import("@angular/core").OutputEmitterRef<void>;
    readonly openDialog: import("@angular/core").OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicEditorControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicEditorControlComponent, "app-chill-polymorphic-editor-control", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "language": { "alias": "language"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "blur": "blur"; "beginDialog": "beginDialog"; "openDialog": "openDialog"; }, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-editor-control.component.d.ts.map