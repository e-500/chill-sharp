import type { ChillPropertySelectOptionTuple } from '../../models/chill-schema.models';
import * as i0 from "@angular/core";
export declare class ChillPolymorphicSelectControlComponent {
    readonly name: import("@angular/core").InputSignal<string>;
    readonly value: import("@angular/core").InputSignal<string>;
    readonly options: import("@angular/core").InputSignal<ChillPropertySelectOptionTuple[]>;
    readonly readOnly: import("@angular/core").InputSignal<boolean>;
    readonly valueChange: import("@angular/core").OutputEmitterRef<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChillPolymorphicSelectControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChillPolymorphicSelectControlComponent, "app-chill-polymorphic-select-control", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
//# sourceMappingURL=chill-polymorphic-select-control.component.d.ts.map