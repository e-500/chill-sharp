import { WorkspaceService, type WorkspaceTaskInstance } from '../services/workspace.service';
import * as i0 from "@angular/core";
export declare class WorkspaceTaskbarComponent {
    readonly workspace: WorkspaceService;
    activateTask(taskId: string): void;
    closeTask(taskId: string): void;
    taskBreadcrumb(task: WorkspaceTaskInstance): string;
    private entityBreadcrumbLabel;
    private readText;
    private isRecord;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkspaceTaskbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WorkspaceTaskbarComponent, "app-workspace-taskbar", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=workspace-taskbar.component.d.ts.map