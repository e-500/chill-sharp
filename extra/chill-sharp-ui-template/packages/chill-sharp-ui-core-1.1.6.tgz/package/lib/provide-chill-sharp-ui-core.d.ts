import { InjectionToken, Provider } from '@angular/core';
export interface ChillSharpUiCoreOptions {
    /** Client-owned theme identifiers in addition to the built-in bright, dark, and soft themes. */
    additionalThemes?: readonly string[];
}
export declare const CHILL_SHARP_UI_CORE_OPTIONS: InjectionToken<ChillSharpUiCoreOptions>;
export declare function provideChillSharpUiCore(options?: ChillSharpUiCoreOptions): Provider[];
//# sourceMappingURL=provide-chill-sharp-ui-core.d.ts.map